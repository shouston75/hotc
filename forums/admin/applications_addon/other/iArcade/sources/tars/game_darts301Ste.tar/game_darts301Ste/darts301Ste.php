<?php

/*
+----------------------------------------------------------------------+
| This file ( darts301Ste.php ) & Tar archive ( game_darts301Ste.tar ) |
| was created automatically with the Enhanced Arcade                   |
| available free from http://ipbcoding.com                             |
| Created May 23 2009, 06:22 PM                                        |
+----------------------------------------------------------------------+
*/

$config = array(

gname					=>		"darts301Ste",
gtitle				=>  	"Darts - 301",
bgcolor				=>  	"000000",
gwidth				=>  	"640",
gheight				=> 	"480",
active				=>  	"1",
gcat					=>		"1",
highscore_type		=>		"high",

//optional leave blank if not using
gwords				=>  	"Start with a point value of 301 and each number you hit will subtract that value from your starting points. Use the spacebar to aim and throw darts. Watch the status board for important rules and score information.",
object				=>  	"Start with a point value of 301 and each number you hit will subtract that value from your starting points. Use the spacebar to aim and throw darts. Watch the status board for important rules and score information.",
gkeys					=>  	"See in game.",

);?>